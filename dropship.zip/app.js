(function() {
  'use strict';

  var globals = typeof global === 'undefined' ? self : global;
  if (typeof globals.require === 'function') return;

  var modules = {};
  var cache = {};
  var aliases = {};
  var has = {}.hasOwnProperty;

  var expRe = /^\.\.?(\/|$)/;
  var expand = function(root, name) {
    var results = [], part;
    var parts = (expRe.test(name) ? root + '/' + name : name).split('/');
    for (var i = 0, length = parts.length; i < length; i++) {
      part = parts[i];
      if (part === '..') {
        results.pop();
      } else if (part !== '.' && part !== '') {
        results.push(part);
      }
    }
    return results.join('/');
  };

  var dirname = function(path) {
    return path.split('/').slice(0, -1).join('/');
  };

  var localRequire = function(path) {
    return function expanded(name) {
      var absolute = expand(dirname(path), name);
      return globals.require(absolute, path);
    };
  };

  var initModule = function(name, definition) {
    var hot = hmr && hmr.createHot(name);
    var module = {id: name, exports: {}, hot: hot};
    cache[name] = module;
    definition(module.exports, localRequire(name), module);
    return module.exports;
  };

  var expandAlias = function(name) {
    return aliases[name] ? expandAlias(aliases[name]) : name;
  };

  var _resolve = function(name, dep) {
    return expandAlias(expand(dirname(name), dep));
  };

  var require = function(name, loaderPath) {
    if (loaderPath == null) loaderPath = '/';
    var path = expandAlias(name);

    if (has.call(cache, path)) return cache[path].exports;
    if (has.call(modules, path)) return initModule(path, modules[path]);

    throw new Error("Cannot find module '" + name + "' from '" + loaderPath + "'");
  };

  require.alias = function(from, to) {
    aliases[to] = from;
  };

  var extRe = /\.[^.\/]+$/;
  var indexRe = /\/index(\.[^\/]+)?$/;
  var addExtensions = function(bundle) {
    if (extRe.test(bundle)) {
      var alias = bundle.replace(extRe, '');
      if (!has.call(aliases, alias) || aliases[alias].replace(extRe, '') === alias + '/index') {
        aliases[alias] = bundle;
      }
    }

    if (indexRe.test(bundle)) {
      var iAlias = bundle.replace(indexRe, '');
      if (!has.call(aliases, iAlias)) {
        aliases[iAlias] = bundle;
      }
    }
  };

  require.register = require.define = function(bundle, fn) {
    if (bundle && typeof bundle === 'object') {
      for (var key in bundle) {
        if (has.call(bundle, key)) {
          require.register(key, bundle[key]);
        }
      }
    } else {
      modules[bundle] = fn;
      delete cache[bundle];
      addExtensions(bundle);
    }
  };

  require.list = function() {
    var list = [];
    for (var item in modules) {
      if (has.call(modules, item)) {
        list.push(item);
      }
    }
    return list;
  };

  var hmr = globals._hmr && new globals._hmr(_resolve, require, modules, cache);
  require._cache = cache;
  require.hmr = hmr && hmr.wrap;
  require.brunch = true;
  globals.require = require;
})();

(function() {
var global = typeof window === 'undefined' ? this : window;
var __makeRelativeRequire = function(require, mappings, pref) {
  var none = {};
  var tryReq = function(name, pref) {
    var val;
    try {
      val = require(pref + '/node_modules/' + name);
      return val;
    } catch (e) {
      if (e.toString().indexOf('Cannot find module') === -1) {
        throw e;
      }

      if (pref.indexOf('node_modules') !== -1) {
        var s = pref.split('/');
        var i = s.lastIndexOf('node_modules');
        var newPref = s.slice(0, i).join('/');
        return tryReq(name, newPref);
      }
    }
    return none;
  };
  return function(name) {
    if (name in mappings) name = mappings[name];
    if (!name) return;
    if (name[0] !== '.' && pref) {
      var val = tryReq(name, pref);
      if (val !== none) return val;
    }
    return require(name);
  }
};
require.register("animations/animations.ts", function(exports, require, module) {
/// <reference path="../../defs/phaser.d.ts"/>
"use strict";
function makeAnimations(scene) {
    // TITLE
    {
        var config = {
            key: 'titleIdle',
            frames: scene.anims.generateFrameNumbers('title', { start: 0, end: 0 }),
            frameRate: 0,
            repeat: Phaser.FOREVER
        };
        scene.anims.create(config);
        config = {
            key: 'titleFlash',
            frames: scene.anims.generateFrameNumbers('title', { start: 4, end: 7 }),
            frameRate: 30,
            repeat: Phaser.FOREVER
        };
        scene.anims.create(config);
        config = {
            key: 'subtitleIdle',
            frames: scene.anims.generateFrameNumbers('subtitle', { start: 0, end: 1 }),
            frameRate: 2,
            repeat: Phaser.FOREVER
        };
        scene.anims.create(config);
    }
    // DROPSHIP
    {
        var config = {
            key: 'dropshipIdle',
            frames: scene.anims.generateFrameNumbers('dropship', { start: 0, end: 0 }),
            frameRate: 0,
            repeat: Phaser.FOREVER
        };
        scene.anims.create(config);
    }
    // UNITS
    // MARINE
    {
        var name = 'marine';
        config = {
            key: name + 'Idle',
            frames: scene.anims.generateFrameNumbers(name, { start: 0, end: 7 }),
            frameRate: 5,
            repeat: Phaser.FOREVER,
            repeatDelay: 1000
        };
        scene.anims.create(config);
        config = {
            key: name + 'Move',
            frames: scene.anims.generateFrameNumbers(name, { start: 8, end: 15 }),
            frameRate: 10,
            repeat: Phaser.FOREVER
        };
        scene.anims.create(config);
        config = {
            key: name + 'AirUp',
            frames: scene.anims.generateFrameNumbers(name, { start: 16, end: 16 }),
            frameRate: 10,
            repeat: Phaser.FOREVER
        };
        scene.anims.create(config);
        config = {
            key: name + 'AirDown',
            frames: scene.anims.generateFrameNumbers(name, { start: 24, end: 24 }),
            frameRate: 10,
            repeat: Phaser.FOREVER
        };
        scene.anims.create(config);
        config = {
            key: name + 'Hurt',
            frames: scene.anims.generateFrameNumbers(name, { start: 32, end: 32 }),
            frameRate: 10,
            repeat: Phaser.FOREVER
        };
        scene.anims.create(config);
        config = {
            key: name + 'Windup',
            frames: scene.anims.generateFrameNumbers(name, { start: 40, end: 40 }),
            frameRate: 10,
            repeat: 0
        };
        scene.anims.create(config);
        config = {
            key: name + 'Cooldown',
            frames: scene.anims.generateFrameNumbers(name, { start: 48, end: 51 }),
            frameRate: 10,
            repeat: 0
        };
        scene.anims.create(config);
        config = {
            key: name + 'Die',
            frames: scene.anims.generateFrameNumbers(name, { start: 56, end: 60 }),
            frameRate: 20,
            repeat: 0
        };
        scene.anims.create(config);
    }
    // ALIEN
    {
        var name = 'alien';
        config = {
            key: name + 'Idle',
            frames: scene.anims.generateFrameNumbers(name, { start: 0, end: 7 }),
            frameRate: 5,
            repeat: Phaser.FOREVER,
            repeatDelay: 1000
        };
        scene.anims.create(config);
        config = {
            key: name + 'Move',
            frames: scene.anims.generateFrameNumbers(name, { start: 8, end: 15 }),
            frameRate: 12,
            repeat: Phaser.FOREVER
        };
        scene.anims.create(config);
        config = {
            key: name + 'AirUp',
            frames: scene.anims.generateFrameNumbers(name, { start: 16, end: 16 }),
            frameRate: 10,
            repeat: Phaser.FOREVER
        };
        scene.anims.create(config);
        config = {
            key: name + 'AirDown',
            frames: scene.anims.generateFrameNumbers(name, { start: 24, end: 24 }),
            frameRate: 10,
            repeat: Phaser.FOREVER
        };
        scene.anims.create(config);
        config = {
            key: name + 'Hurt',
            frames: scene.anims.generateFrameNumbers(name, { start: 32, end: 32 }),
            frameRate: 10,
            repeat: Phaser.FOREVER
        };
        scene.anims.create(config);
        config = {
            key: name + 'Windup',
            frames: scene.anims.generateFrameNumbers(name, { start: 40, end: 43 }),
            frameRate: 10,
            repeat: 0
        };
        scene.anims.create(config);
        config = {
            key: name + 'Cooldown',
            frames: scene.anims.generateFrameNumbers(name, { start: 48, end: 52 }),
            frameRate: 10,
            repeat: 0
        };
        scene.anims.create(config);
        config = {
            key: name + 'Die',
            frames: scene.anims.generateFrameNumbers(name, { start: 56, end: 60 }),
            frameRate: 20,
            repeat: 0
        };
        scene.anims.create(config);
    }
    // EFFECTS
    {
        var name = 'effect';
        config = {
            key: name + 'marineHit',
            frames: scene.anims.generateFrameNumbers(name, { start: 0, end: 8 }),
            frameRate: 20,
            repeat: 0
        };
        scene.anims.create(config);
        config = {
            key: name + 'marineFire',
            frames: scene.anims.generateFrameNumbers(name, { start: 10, end: 16 }),
            frameRate: 20,
            repeat: 0
        };
        scene.anims.create(config);
        config = {
            key: name + 'alienHit',
            frames: scene.anims.generateFrameNumbers(name, { start: 20, end: 27 }),
            frameRate: 20,
            repeat: 0
        };
        scene.anims.create(config);
        config = {
            key: name + 'dropshipThrust',
            frames: scene.anims.generateFrameNumbers(name, { start: 30, end: 37 }),
            frameRate: 20,
            repeat: 0
        };
        scene.anims.create(config);
        config = {
            key: name + 'dropshipGlide',
            frames: scene.anims.generateFrameNumbers(name, { start: 40, end: 46 }),
            frameRate: 20,
            repeat: 0
        };
        scene.anims.create(config);
        config = {
            key: name + 'pull',
            frames: scene.anims.generateFrameNumbers('pull', { start: 0, end: 1 }),
            frameRate: 20,
            repeat: Phaser.FOREVER
        };
        scene.anims.create(config);
    }
    // BUILDINGS
    // MARINE BASE
    {
        var config = {
            key: 'marineBase',
            frames: scene.anims.generateFrameNumbers('base', { start: 0, end: 0 }),
            frameRate: 0,
            repeat: Phaser.FOREVER
        };
        scene.anims.create(config);
    }
    // ALIEN BASE
    {
        var config = {
            key: 'alienBase',
            frames: scene.anims.generateFrameNumbers('base', { start: 1, end: 1 }),
            frameRate: 0,
            repeat: Phaser.FOREVER
        };
        scene.anims.create(config);
    }
    // TEXT
    {
        var name = 'text';
        config = {
            key: name + 'cargoFull',
            frames: scene.anims.generateFrameNumbers(name, { start: 0, end: 1 }),
            frameRate: 2,
            repeat: Phaser.FOREVER
        };
        scene.anims.create(config);
        config = {
            key: name + 'defeat',
            frames: scene.anims.generateFrameNumbers(name, { start: 2, end: 3 }),
            frameRate: 1.5,
            repeat: Phaser.FOREVER
        };
        scene.anims.create(config);
        config = {
            key: name + 'victory',
            frames: scene.anims.generateFrameNumbers(name, { start: 4, end: 5 }),
            frameRate: 1.5,
            repeat: Phaser.FOREVER
        };
        scene.anims.create(config);
    }
    // TILES
    tileConfig(scene, 'fill', 0, 3);
    tileConfig(scene, 'floor', 8, 3);
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = makeAnimations;
function tileConfig(scene, keyName, start, amount) {
    for (var i = start; i < start + amount; i++) {
        var config = {
            key: keyName + String(i - start),
            frames: scene.anims.generateFrameNumbers('ground', { start: i, end: i }),
            frameRate: 0,
            repeat: 0
        };
        scene.anims.create(config);
    }
}
//# sourceMappingURL=animations.js.map
});

;require.register("initialize.ts", function(exports, require, module) {
/// <reference path="../defs/phaser.d.ts"/>
"use strict";
var loadScene_1 = require("./scenes/loadScene");
var titleScene_1 = require("./scenes/titleScene");
var gameScene_1 = require("./scenes/gameScene");
var game = new Phaser.Game({
    // See <https://github.com/photonstorm/phaser/blob/master/src/boot/Config.js>
    width: 450,
    height: 250,
    zoom: 3,
    // resolution: 1,
    type: Phaser.AUTO,
    // parent: null,
    // canvas: null,
    // canvasStyle: null,
    // seed: null,
    title: 'LD41 Game',
    url: '',
    version: '0.0.1',
    input: {
        keyboard: true,
        mouse: false,
        touch: false,
        gamepad: true
    },
    // disableContextMenu: false,
    // banner: false
    banner: {
        // hidePhaser: false,
        // text: 'white',
        background: ['#e54661', '#ffa644', '#998a2f', '#2c594f', '#002d40']
    },
    // fps: {
    //   min: 10,
    //   target: 60,
    //   forceSetTimeout: false,
    // },
    pixelArt: true,
    // transparent: false,
    // clearBeforeRender: true,
    // backgroundColor: 0x000000, // black
    loader: {
        // baseURL: '',
        path: 'assets/',
        maxParallelDownloads: 6,
    },
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 350 },
            debug: false
        }
    },
    scene: [
        loadScene_1.default,
        titleScene_1.default,
        gameScene_1.default
    ]
});
//# sourceMappingURL=initialize.js.map
});

require.register("objects/alien.ts", function(exports, require, module) {
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var unit_1 = require("../objects/unit");
var Alien = (function (_super) {
    __extends(Alien, _super);
    function Alien(scene, x, y) {
        return _super.call(this, scene, 'alien', x, y) || this;
    }
    Alien.prototype.created = function () {
        this.body.setSize(14, 14, true);
        this.unitStats.team = 1;
        this.unitStats.moveSpeed = 40;
        this.unitStats.jumpPower = 180;
        this.unitStats.jumpInterval = 200;
        this.unitStats.attackRange = 6;
        this.unitStats.attackPower = 20;
    };
    Alien.prototype.update = function () {
        _super.prototype.update.call(this);
    };
    Alien.prototype.jump = function () {
        _super.prototype.jump.call(this);
        if (this.unitInput.inputLeft)
            this.body.velocity.x -= 40;
        else if (this.unitInput.inputRight)
            this.body.velocity.x += 40;
    };
    Alien.prototype.attackEffect = function () {
        var sound = this.scene.sound.add('sword');
        sound.play();
    };
    Alien.prototype.attackTargetEffect = function (target) {
        this.gameScene.addEffect('alienHit', target.getCenter().x, target.getCenter().y);
    };
    Alien.prototype.dieEffect = function () {
        var sound = this.scene.sound.add('orcdeath');
        sound.play();
    };
    return Alien;
}(unit_1.default));
exports.Alien = Alien;
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Alien;
//# sourceMappingURL=alien.js.map
});

require.register("objects/alienBase.ts", function(exports, require, module) {
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/// <reference path="../../defs/phaser.d.ts"/>
var unit_1 = require("./unit");
var alien_1 = require("./alien");
var AlienBase = (function (_super) {
    __extends(AlienBase, _super);
    function AlienBase(scene, x, y) {
        var _this = _super.call(this, scene, 'base', x, y, true) || this;
        _this.alienSpawnInterval = 30;
        _this.alienCounter = 0;
        _this.aliensToSpawn = 2;
        return _this;
    }
    AlienBase.prototype.created = function () {
        //this.body.setSize(10, 10, true);
        this.anims.play('alienBase');
        this.unitStats.team = 1;
        this.unitStats.health = 100;
    };
    AlienBase.prototype.update = function () {
        _super.prototype.update.call(this);
        if (this.aliensToSpawn > 0) {
            this.alienCounter++;
            if (this.alienCounter > this.alienSpawnInterval) {
                this.gameScene.addUnit(new alien_1.default(this.gameScene, this.getCenter().x, this.getCenter().y + 30));
                this.alienCounter = 0;
                this.aliensToSpawn--;
            }
        }
    };
    AlienBase.prototype.dieEffect = function () {
        this.gameScene.victory();
    };
    return AlienBase;
}(unit_1.default));
exports.AlienBase = AlienBase;
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = AlienBase;
//# sourceMappingURL=alienBase.js.map
});

require.register("objects/dropship.ts", function(exports, require, module) {
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Dropship = (function (_super) {
    __extends(Dropship, _super);
    function Dropship(scene, x, y) {
        var _this = _super.call(this, scene, x, y, "dropship") || this;
        _this.maxUpVel = -150;
        _this.maxDownVel = 200;
        _this.maxSpeed = 200;
        _this.health = 100;
        _this.cargoBaySize = 3;
        _this.dropInterval = 0;
        _this.glideInterval = 20;
        _this.glideCounter = 0;
        _this.scene.add.existing(_this);
        _this.scene.physics.add.existing(_this);
        _this.gameScene = scene;
        _this.up = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.UP);
        _this.down = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.DOWN);
        _this.left = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.LEFT);
        _this.right = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.RIGHT);
        _this.pickup = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.Z);
        _this.dropoff = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.X);
        _this.munitions = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.C);
        _this.cargoBay = [];
        _this.pullSound = scene.sound.add('pull');
        _this.pickupSound = scene.sound.add('pickup');
        _this.dropSound = scene.sound.add('dropoff');
        _this.pullEffect = scene.add.sprite(0, 0, 'pull');
        _this.pullEffect.setAlpha(0.3, 0.3, 0.02, 0.02);
        _this.pullEffect.play('effectpull');
        _this.pullEffect.setVisible(false);
        _this.cargoText = scene.add.sprite(_this.scene.sys.game.config.width / 2, 100, 'text');
        _this.cargoText.play('textcargoFull');
        _this.cargoText.setVisible(false);
        _this.cargoText.setScrollFactor(0, 0);
        return _this;
    }
    Dropship.prototype.update = function () {
        if (!this.anims.currentAnim) {
            this.anims.play('dropshipIdle');
            this.body.allowGravity = false;
        }
        this.updateControl();
    };
    Dropship.prototype.updateControl = function () {
        this.glideCounter++;
        if (this.up.isDown ||
            (this.gameScene.gamepad && this.gameScene.gamepad.buttons[this.gameScene.gamepadConfig.UP].pressed)) {
            this.body.velocity.y -= 2;
            if (this.glideCounter > this.glideInterval) {
                this.glideCounter = 0;
                this.gameScene.addEffect('dropshipGlide', this.getCenter().x - 12, this.getCenter().y + 8, false);
                this.gameScene.addEffect('dropshipGlide', this.getCenter().x + 12, this.getCenter().y + 8, false);
            }
        }
        else {
            this.body.velocity.y += 0.5;
        }
        if (this.down.isDown) {
            this.body.velocity.y += 2;
            if (this.glideCounter > this.glideInterval) {
                this.glideCounter = 0;
                this.gameScene.addEffect('dropshipGlide', this.getCenter().x, this.getCenter().y - 8, false, 180);
            }
        }
        this.body.velocity.y = Phaser.Math.Clamp(this.body.velocity.y, this.maxUpVel, this.maxDownVel);
        if (this.body.velocity.y > this.maxUpVel && Phaser.Input.Keyboard.JustDown(this.up)) {
            if (this.body.touching.down)
                this.body.velocity.y -= 60;
            else
                this.body.velocity.y -= 30;
            this.gameScene.addEffect('dropshipThrust', this.getCenter().x - 12, this.getCenter().y + 8, false);
            this.gameScene.addEffect('dropshipThrust', this.getCenter().x + 12, this.getCenter().y + 8, false);
        }
        else if (this.body.velocity.y < this.maxDownVel && Phaser.Input.Keyboard.JustDown(this.down)) {
            this.body.velocity.y += 30;
            this.gameScene.addEffect('dropshipThrust', this.getCenter().x, this.getCenter().y - 8, false, 180);
        }
        this.body.velocity.y = Phaser.Math.Clamp(this.body.velocity.y, this.maxUpVel, this.maxDownVel);
        if (this.left.isDown) {
            this.body.velocity.x -= 3;
            this.flipX = true;
            if (this.glideCounter > this.glideInterval) {
                this.glideCounter = 0;
                this.gameScene.addEffect('dropshipGlide', this.getCenter().x + 26, this.getCenter().y, false, -90);
            }
        }
        if (this.right.isDown) {
            this.body.velocity.x += 3;
            this.flipX = false;
            if (this.glideCounter > this.glideInterval) {
                this.glideCounter = 0;
                this.gameScene.addEffect('dropshipGlide', this.getCenter().x - 26, this.getCenter().y, false, 90);
            }
        }
        if (!this.left.isDown && !this.right.isDown) {
            this.body.velocity.x -= Math.sign(this.body.velocity.x) * 2;
            if (Math.abs(this.body.velocity.x) < 2)
                this.body.velocity.x = 0;
        }
        this.body.velocity.x = Phaser.Math.Clamp(this.body.velocity.x, -this.maxSpeed, this.maxSpeed);
        if (this.body.velocity.x > -this.maxSpeed && Phaser.Input.Keyboard.JustDown(this.left)) {
            this.body.velocity.x -= 30;
            this.gameScene.addEffect('dropshipThrust', this.getCenter().x + 26, this.getCenter().y, false, -90);
        }
        else if (this.body.velocity.x < this.maxSpeed && Phaser.Input.Keyboard.JustDown(this.right)) {
            this.body.velocity.x += 30;
            this.gameScene.addEffect('dropshipThrust', this.getCenter().x - 26, this.getCenter().y, false, 90);
        }
        this.body.velocity.x = Phaser.Math.Clamp(this.body.velocity.x, -this.maxSpeed, this.maxSpeed);
        if (this.body.position.y < Math.abs(this.maxUpVel / 2)) {
            this.body.velocity.y = Math.max(-2 * this.body.position.y, this.body.velocity.y);
        }
        if (this.body.position.x < Math.abs(this.maxSpeed / 4)) {
            this.body.velocity.x = Math.max(-4 * this.body.position.x, this.body.velocity.x);
        }
        if (this.body.position.x + this.width > this.gameScene.worldSize.x - Math.abs(this.maxSpeed / 4)) {
            this.body.velocity.x = Math.min(4 * (this.gameScene.worldSize.x - this.width - this.body.position.x), this.body.velocity.x);
        }
        if (this.body.touching.down) {
            this.body.velocity.x -= Math.sign(this.body.velocity.x) * 5;
            if (Math.abs(this.body.velocity.x) < 5)
                this.body.velocity.x = 0;
        }
        if (this.pickup.isDown) {
            if (this.cargoBay.length < this.cargoBaySize) {
                this.pickingUp();
                if (!this.pullSound.isPlaying)
                    this.pullSound.play();
                this.pullEffect.setVisible(true);
                this.pullEffect.setPosition(this.getCenter().x, this.getCenter().y + 70);
                this.cargoText.setVisible(false);
            }
            else {
                this.cargoText.setVisible(true);
                this.pullEffect.setVisible(false);
            }
        }
        else {
            if (this.pullSound.isPlaying)
                this.pullSound.stop();
            this.pullEffect.setVisible(false);
            this.cargoText.setVisible(false);
            if (Phaser.Input.Keyboard.JustDown(this.dropoff) ||
                (this.dropoff.isDown && this.dropInterval <= 0)) {
                this.droppingOff();
            }
        }
        if (this.dropInterval > 0)
            this.dropInterval--;
    };
    Dropship.prototype.pickingUp = function () {
        for (var _i = 0, _a = this.gameScene.unitsByTeam[0].getChildren(); _i < _a.length; _i++) {
            var object = _a[_i];
            if (object.active &&
                object.unitStats.health > 0 &&
                object.body &&
                object.getCenter().y - this.getCenter().y > -10 &&
                object.getCenter().y - this.getCenter().y < 250 &&
                Math.abs(object.getCenter().x - this.getCenter().x) < 32) {
                if (object.getCenter().y - this.getCenter().y < 10) {
                    object.setActive(false);
                    object.setVisible(false);
                    this.cargoBay.push(object);
                    this.pickupSound.play();
                }
                else {
                    object.body.velocity.y -= Math.min(30, 500 / (object.getCenter().y - this.getCenter().y));
                }
            }
        }
    };
    Dropship.prototype.droppingOff = function () {
        if (this.cargoBay.length > 0) {
            this.dropInterval = 20;
            var object = this.cargoBay.pop();
            object.setActive(true);
            object.setVisible(true);
            object.body.position = new Phaser.Math.Vector2(this.getCenter().x, this.getCenter().y - 3);
            var addXVel = (this.left.isDown ? -10 : 0) + (this.right.isDown ? 10 : 0);
            var addYVel = (this.up.isDown ? -40 : 0) + (this.down.isDown ? 5 : 0);
            object.body.velocity = new Phaser.Math.Vector2(this.body.velocity.x / 1.3 + addXVel, this.body.velocity.y - 10 + addYVel);
            this.dropSound.play();
        }
    };
    return Dropship;
}(Phaser.GameObjects.Sprite));
exports.Dropship = Dropship;
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Dropship;
//# sourceMappingURL=dropship.js.map
});

require.register("objects/marine.ts", function(exports, require, module) {
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var unit_1 = require("../objects/unit");
var Marine = (function (_super) {
    __extends(Marine, _super);
    function Marine(scene, x, y) {
        return _super.call(this, scene, 'marine', x, y) || this;
    }
    Marine.prototype.created = function () {
        this.body.setSize(10, 10, true);
        this.unitStats.attackRange = 160;
        this.unitStats.attackPower = 5;
    };
    Marine.prototype.update = function () {
        _super.prototype.update.call(this);
    };
    Marine.prototype.attackEffect = function () {
        this.gameScene.addEffect('marineFire', this.getCenter().x + (this.flipX ? -10 : 10), this.getCenter().y, this.flipX);
        var sound = this.scene.sound.add('rifle');
        sound.play();
    };
    Marine.prototype.attackTargetEffect = function (target) {
        this.gameScene.addEffect('marineHit', target.getCenter().x, target.getCenter().y);
    };
    Marine.prototype.dieEffect = function () {
        var sound = this.scene.sound.add('marinedeath');
        sound.play();
    };
    return Marine;
}(unit_1.default));
exports.Marine = Marine;
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Marine;
//# sourceMappingURL=marine.js.map
});

require.register("objects/marineBase.ts", function(exports, require, module) {
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/// <reference path="../../defs/phaser.d.ts"/>
var unit_1 = require("./unit");
var marine_1 = require("./marine");
var MarineBase = (function (_super) {
    __extends(MarineBase, _super);
    function MarineBase(scene, x, y) {
        var _this = _super.call(this, scene, 'base', x, y, true) || this;
        _this.marineSpawnInterval = 20;
        _this.marineCounter = 0;
        _this.marinesToSpawn = 3;
        return _this;
    }
    MarineBase.prototype.created = function () {
        //this.body.setSize(10, 10, true);
        this.anims.play('marineBase');
        this.unitStats.health = 100;
    };
    MarineBase.prototype.update = function () {
        _super.prototype.update.call(this);
        if (this.marinesToSpawn > 0) {
            this.marineCounter++;
            if (this.marineCounter > this.marineSpawnInterval) {
                this.gameScene.addUnit(new marine_1.default(this.gameScene, this.getCenter().x, this.getCenter().y + 30));
                this.marineCounter = 0;
                this.marinesToSpawn--;
            }
        }
    };
    MarineBase.prototype.dieEffect = function () {
        this.gameScene.defeat();
    };
    return MarineBase;
}(unit_1.default));
exports.MarineBase = MarineBase;
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = MarineBase;
//# sourceMappingURL=marineBase.js.map
});

require.register("objects/unit.ts", function(exports, require, module) {
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var util_1 = require("../other/util");
var util_2 = require("../other/util");
var UnitState;
(function (UnitState) {
    UnitState[UnitState["Idle"] = 0] = "Idle";
    UnitState[UnitState["Windup"] = 1] = "Windup";
    UnitState[UnitState["Cooldown"] = 2] = "Cooldown";
    UnitState[UnitState["Hurt"] = 3] = "Hurt";
    UnitState[UnitState["Dead"] = 4] = "Dead";
})(UnitState || (UnitState = {}));
var UnitStats = (function () {
    function UnitStats() {
        this.team = 0;
        this.hasGravity = true;
        this.moveSpeed = 30;
        this.acceleration = 3;
        this.jumpPower = 120;
        this.jumpInterval = 500;
        this.jumpCountdown = 500;
        this.health = 100;
        this.aquireRange = 300;
        this.attackPower = 10;
        this.attackRange = 100;
        this.windupFrames = 20;
        this.cooldownFrames = 20;
        this.hurtFrames = 10;
        this.currentActionFrames = 0;
    }
    return UnitStats;
}());
var UnitInput = (function () {
    function UnitInput() {
        this.inputUp = false;
        this.inputDown = false;
        this.inputLeft = false;
        this.inputRight = false;
        this.inputJump = false;
        this.inputAttack = false;
    }
    return UnitInput;
}());
var Unit = (function (_super) {
    __extends(Unit, _super);
    function Unit(scene, animName, x, y, isBuilding) {
        var _this = _super.call(this, scene, x, y, animName) || this;
        _this.targetEvalCounter = 0;
        if (isBuilding === undefined)
            isBuilding = false;
        _this.scene.add.existing(_this);
        _this.scene.physics.add.existing(_this, isBuilding);
        _this.gameScene = scene;
        _this.animName = animName;
        _this.isBuilding = isBuilding;
        _this.unitState = UnitState.Idle;
        _this.unitStats = new UnitStats();
        _this.unitInput = new UnitInput();
        _this.unitTarget = null;
        return _this;
    }
    Unit.prototype.created = function () {
    };
    Unit.prototype.update = function () {
        if (this.active && !this.isBuilding) {
            this.updateState();
            this.updateAI();
            this.updateControl();
            this.updateAnimations();
        }
        if (this.isBuilding && this.unitState == UnitState.Dead)
            this.destroy();
    };
    Unit.prototype.updateState = function () {
        if (this.unitState != UnitState.Idle) {
            this.unitStats.currentActionFrames++;
            if (this.unitState == UnitState.Hurt) {
                if (this.unitStats.currentActionFrames >= this.unitStats.hurtFrames)
                    this.unitState = UnitState.Idle;
            }
            else if (this.unitState == UnitState.Windup) {
                if (this.unitStats.currentActionFrames >= this.unitStats.windupFrames) {
                    this.unitState = UnitState.Cooldown;
                    this.unitStats.currentActionFrames = 0;
                    this.executeAttack();
                }
            }
            else if (this.unitState == UnitState.Cooldown) {
                if (this.unitStats.currentActionFrames >= this.unitStats.cooldownFrames)
                    this.unitState = UnitState.Idle;
            }
            else if (this.unitState == UnitState.Dead) {
                if (this.unitStats.currentActionFrames >= 30)
                    this.destroy();
            }
        }
    };
    Unit.prototype.updateAI = function () {
        if (this.unitState == UnitState.Dead)
            return;
        this.refreshTarget();
        if (!this.unitTarget) {
            if (this.unitStats.team == 0) {
                this.unitInput.inputRight = true;
                this.unitInput.inputLeft = false;
            }
            else {
                this.unitInput.inputRight = false;
                this.unitInput.inputLeft = true;
            }
        }
        else {
            if (this.getCenter().x < this.unitTarget.getCenter().x) {
                this.unitInput.inputRight = true;
                this.unitInput.inputLeft = false;
            }
            else {
                this.unitInput.inputRight = false;
                this.unitInput.inputLeft = true;
            }
            if (this.getCenter().y - 32 > this.unitTarget.getCenter().y) {
                this.unitStats.jumpCountdown -= 5;
            }
            this.tryAttack();
        }
    };
    Unit.prototype.updateControl = function () {
        if (!this.body)
            return;
        if (this.unitState == UnitState.Idle) {
            if (this.unitInput.inputAttack) {
                this.unitState = UnitState.Windup;
                this.unitStats.currentActionFrames = 0;
            }
            else {
                this.unitStats.jumpCountdown--;
                if ((this.unitInput.inputJump ||
                    this.unitStats.jumpCountdown <= 0 ||
                    (this.unitStats.jumpCountdown < 1000 &&
                        (this.unitInput.inputLeft && this.body.touching.left) || (this.unitInput.inputRight && this.body.touching.right))) &&
                    this.body.touching.down && this.body.velocity.y > -this.unitStats.jumpPower / 2) {
                    this.jump();
                }
                if (this.unitInput.inputLeft) {
                    this.flipX = true;
                    if (this.body.velocity.x > -this.unitStats.moveSpeed) {
                        this.body.velocity.x -= this.unitStats.acceleration;
                        this.body.velocity.x = Math.max(this.body.velocity.x, -this.unitStats.moveSpeed);
                    }
                }
                if (this.unitInput.inputRight) {
                    this.flipX = false;
                    if (this.body.velocity.x < this.unitStats.moveSpeed) {
                        this.body.velocity.x += this.unitStats.acceleration;
                        this.body.velocity.x = Math.min(this.body.velocity.x, this.unitStats.moveSpeed);
                    }
                }
                if (this.body.touching.down &&
                    ((!this.unitInput.inputLeft && !this.unitInput.inputRight) ||
                        Math.abs(this.body.velocity.x) > this.unitStats.moveSpeed)) {
                    this.body.velocity.x -= Math.sign(this.body.velocity.x) * 2;
                    if (Math.abs(this.body.velocity.x) < 2)
                        this.body.velocity.x = 0;
                }
            }
        }
        else if (this.body.touching.down) {
            this.body.velocity.x -= Math.sign(this.body.velocity.x);
            if (Math.abs(this.body.velocity.x) < 1)
                this.body.velocity.x = 0;
        }
    };
    Unit.prototype.updateAnimations = function () {
        // animation controller
        if (this.unitState == UnitState.Dead) {
            this.playAnimation('Die');
            this.anims.setCurrentFrame(this.anims.currentAnim.getFrameByProgress(this.unitStats.currentActionFrames / 30));
        }
        else if (this.unitState == UnitState.Hurt) {
            this.playAnimation('Hurt');
        }
        else if (this.unitState == UnitState.Windup) {
            this.playAnimation('Windup');
        }
        else if (this.unitState == UnitState.Cooldown) {
            this.playAnimation('Cooldown');
            // broken in phaser
            //this.anims.setProgress(this.unitStats.currentActionFrames / this.unitStats.cooldownFrames);
            this.anims.setCurrentFrame(this.anims.currentAnim.getFrameByProgress(this.unitStats.currentActionFrames / this.unitStats.cooldownFrames));
        }
        else if (!this.body.touching.down) {
            if (this.body.velocity.y < 0)
                this.playAnimation('AirUp');
            else
                this.playAnimation('AirDown');
        }
        else if (Math.abs(this.body.velocity.x) > 0) {
            this.playAnimation('Move');
        }
        else {
            this.playAnimation('Idle');
        }
    };
    Unit.prototype.jump = function () {
        this.body.velocity.y -= this.unitStats.jumpPower;
        this.unitStats.jumpCountdown = Math.random() * this.unitStats.jumpInterval;
    };
    Unit.prototype.executeAttack = function () {
        if (this.unitTarget && this.unitTarget.active && this.unitTarget.body && this.body) {
            if (this.unitTarget.getCenter().x < this.getCenter().x)
                this.flipX = true;
            else
                this.flipX = false;
            this.attackEffect();
            if (util_1.DistanceSqRects(this.unitTarget.body, this.body) <= this.unitStats.attackRange * this.unitStats.attackRange) {
                this.attackTargetEffect(this.unitTarget);
                this.unitTarget.takeDamage(this.unitStats.attackPower);
            }
        }
    };
    // override for effects
    Unit.prototype.attackEffect = function () { };
    // override for effects
    Unit.prototype.attackTargetEffect = function (target) { };
    Unit.prototype.takeDamage = function (damage, stun) {
        if (stun === undefined)
            stun = 0;
        this.unitStats.health -= damage;
        this.hitEffect();
        if (this.unitStats.health <= 0) {
            this.dieEffect();
            this.unitState = UnitState.Dead;
            this.unitStats.currentActionFrames = 0;
        }
        else if (stun > 0) {
            this.unitState = UnitState.Hurt;
            this.unitStats.currentActionFrames = stun;
        }
    };
    // override for effects
    Unit.prototype.hitEffect = function () { };
    // override for effects
    Unit.prototype.dieEffect = function () { };
    Unit.prototype.refreshTarget = function () {
        this.targetEvalCounter--;
        if (this.unitTarget && this.targetEvalCounter >= 0) {
            if (!this.unitTarget.active ||
                !this.unitTarget.body ||
                this.unitTarget.unitStats.health <= 0 ||
                util_1.DistanceSqRects(this.unitTarget.body, this.body) > this.unitStats.aquireRange * this.unitStats.aquireRange)
                this.unitTarget = null;
            else
                return true;
        }
        var targetTeam = this.unitStats.team == 0 ? 1 : 0;
        var minDistance = this.unitStats.aquireRange * this.unitStats.aquireRange;
        for (var _i = 0, _a = this.gameScene.unitsByTeam[targetTeam].getChildren(); _i < _a.length; _i++) {
            var object = _a[_i];
            if (object.active && object.unitStats.health > 0 && object.body) {
                var distance = util_2.DistanceSq(object.getCenter(), this.getCenter());
                if (distance < minDistance && (!this.unitTarget || !object.isBuilding)) {
                    this.unitTarget = object;
                    minDistance = distance;
                }
            }
        }
        if (this.unitTarget) {
            this.targetEvalCounter = Math.random() * 60 + 30;
            return true;
        }
        return false;
    };
    Unit.prototype.tryAttack = function () {
        if (this.unitState == UnitState.Idle &&
            util_1.DistanceSqRects(this.unitTarget.body, this.body) < this.unitStats.attackRange * this.unitStats.attackRange) {
            this.unitState = UnitState.Windup;
            this.unitStats.currentActionFrames = 0;
            if (this.unitTarget.getCenter().x < this.getCenter().x)
                this.flipX = true;
            else
                this.flipX = false;
        }
    };
    // play unit animation only if the same animation is not already playing (so it's not constantly restarted)
    Unit.prototype.playAnimation = function (key) {
        if (this.anims.getCurrentKey() != this.animName + key)
            this.anims.play(this.animName + key);
    };
    return Unit;
}(Phaser.Physics.Arcade.Sprite));
exports.Unit = Unit;
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Unit;
//# sourceMappingURL=unit.js.map
});

require.register("other/util.ts", function(exports, require, module) {
/// <reference path="../../defs/phaser.d.ts"/>
"use strict";
function DistanceSq(p1, p2) {
    return Phaser.Math.Distance.Squared(p1.x, p1.y, p2.x, p2.y);
}
exports.DistanceSq = DistanceSq;
function DistanceSq4(p1x, p1y, p2x, p2y) {
    return Phaser.Math.Distance.Squared(p1x, p1y, p2x, p2y);
}
exports.DistanceSq4 = DistanceSq4;
function DistanceSqRects(body1, body2) {
    var left = body2.right < body1.left;
    var right = body1.right < body2.left;
    var bottom = body2.bottom < body1.top;
    var top = body1.bottom < body2.top;
    if (top && left)
        return DistanceSq4(body1.left, body1.bottom, body2.right, body2.top);
    else if (left && bottom)
        return DistanceSq4(body1.left, body1.top, body2.right, body2.bottom);
    else if (bottom && right)
        return DistanceSq4(body1.right, body1.top, body2.left, body2.bottom);
    else if (right && top)
        return DistanceSq4(body1.right, body1.bottom, body2.left, body2.top);
    else if (left)
        return (body1.left - body2.right) * (body1.left - body2.right);
    else if (right)
        return (body2.left - body1.right) * (body2.left - body1.right);
    else if (bottom)
        return (body1.top - body2.bottom) * (body1.top - body2.bottom);
    else if (top)
        return (body2.top - body1.bottom) * (body2.top - body1.bottom);
    else
        return 0;
}
exports.DistanceSqRects = DistanceSqRects;
//# sourceMappingURL=util.js.map
});

;require.register("scenes/gameScene.ts", function(exports, require, module) {
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var tilemap_1 = require("../tiles/tilemap");
var dropship_1 = require("../objects/dropship");
var GameScene = (function (_super) {
    __extends(GameScene, _super);
    function GameScene(test) {
        var _this = _super.call(this, {
            key: 'GameScene'
        }) || this;
        _this.worldSize = Phaser.Math.Vector2;
        _this.readyToLeave = 0;
        _this.level = 1;
        return _this;
    }
    GameScene.prototype.init = function (data) {
    };
    GameScene.prototype.preload = function () {
    };
    GameScene.prototype.create = function () {
        this.endKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ESC);
        this.readyToLeave = 0;
        var bg = this.add.image(0, 0, 'background');
        bg.setOrigin(0, 0);
        bg.setScrollFactor(0, 0);
        this.effects = new Phaser.GameObjects.Group(this);
        this.input.gamepad.on('down', function (pad, button, value, data) {
            this.gamepad = pad;
        });
        this.gamepadConfig = Phaser.Input.Gamepad.Configs.XBOX_360;
        this.units = new Phaser.GameObjects.Group(this);
        this.unitsByTeam = [];
        for (var i = 0; i < 2; i++)
            this.unitsByTeam.push(new Phaser.GameObjects.Group(this));
        this.worldSize = new Phaser.Math.Vector2(1500, 500);
        // this also sets the bases
        this.tilemap = new tilemap_1.default(this, this.worldSize);
        var dropship = new dropship_1.default(this, 180, this.worldSize.y / 2);
        this.physics.add.collider(dropship, this.tilemap.mapCollision);
        this.dropship = dropship;
        this.cameras.main.startFollow(this.dropship, true);
        this.cameras.main.setBounds(0, 0, this.worldSize.x, this.worldSize.y);
        this.cameras.main.fadeIn(1000);
        this.centerText = this.add.sprite(this.sys.game.config.width / 2, 60, 'text');
        this.centerText.play('textvictory');
        this.centerText.setVisible(false);
        this.centerText.setScrollFactor(0, 0);
        this.hpBars = this.add.graphics();
        this.loadLevelParams();
    };
    GameScene.prototype.update = function (time, delta) {
        if (this.readyToLeave == 1) {
            this.scene.start('TitleScene');
            return;
        }
        else if (this.readyToLeave == 2) {
            this.scene.start('GameScene');
            return;
        }
        // would rather do something like this for more control, but can't get it to not jitter the dropship
        //this.cameras.main.scrollX = Math.round(this.dropship.getCenter().x) - this.sys.game.config.width / 2;
        //this.cameras.main.scrollY = Math.round(this.dropship.getCenter().y) - this.sys.game.config.height / 2;
        this.dropship.update();
        this.hpBars.clear();
        this.hpBars.fillStyle(0x00ff55);
        for (var _i = 0, _a = this.units.getChildren(); _i < _a.length; _i++) {
            var object = _a[_i];
            object.update(delta);
            if (object.body && object.active)
                this.hpBars.fillRect(object.body.left, object.body.bottom + 5, object.body.width * (object.unitStats.health / 100), 5);
        }
        for (var _b = 0, _c = this.effects.getChildren(); _b < _c.length; _b++) {
            var effect = _c[_b];
            if (effect.anims.getProgress() == 1)
                effect.destroy();
        }
        if (this.endKey.isDown) {
            this.defeat();
        }
    };
    GameScene.prototype.addUnit = function (unit) {
        unit.created();
        if (!unit.isBuilding)
            this.physics.add.collider(unit, this.tilemap.mapCollision);
        this.units.add(unit);
        this.unitsByTeam[unit.unitStats.team].add(unit);
        return unit;
    };
    GameScene.prototype.addEffect = function (name, effectX, effectY, flippedX, angle) {
        if (flippedX === undefined)
            flippedX = Math.random() < 0.5;
        if (angle === undefined)
            angle = 0;
        var effect = this.add.sprite(effectX, effectY, 'effect');
        effect.play('effect' + name);
        effect.flipX = flippedX;
        effect.setAngle(angle);
        this.effects.add(effect);
    };
    GameScene.prototype.victory = function () {
        this.centerText.play('textvictory');
        this.centerText.setVisible(true);
        this.cameras.main.fadeOut(5500);
        this.timedEvent = this.time.delayedCall(6500, this.continue, [], this);
    };
    GameScene.prototype.defeat = function () {
        this.centerText.play('textdefeat');
        this.centerText.setVisible(true);
        this.cameras.main.fadeOut(5500);
        this.timedEvent = this.time.delayedCall(5500, this.backToTitle, [], this);
    };
    GameScene.prototype.backToTitle = function () {
        this.readyToLeave = 1;
    };
    GameScene.prototype.continue = function () {
        this.readyToLeave = 2;
        this.level++;
    };
    GameScene.prototype.loadLevelParams = function () {
        this.levelText = this.add.text(this.sys.game.config.width / 2, 60, 'Level ' + String(this.level)).setFontFamily('Impact').setFontSize(16).setColor('#dd1200');
        this.levelText.setScrollFactor(0, 0);
        this.timedEvent = this.time.delayedCall(3000, this.clearLevelText, [], this);
        if (this.level == 1) {
        }
        else if (this.level == 2) {
            this.marineBase.marineSpawnInterval = 30;
            this.marineBase.marinesToSpawn = 5;
            this.alienBase.alienSpawnInterval = 10;
            this.alienBase.aliensToSpawn = 4;
        }
        else if (this.level == 3) {
            this.marineBase.marineSpawnInterval = 30;
            this.marineBase.marinesToSpawn = 1;
            this.alienBase.alienSpawnInterval = 10;
            this.alienBase.aliensToSpawn = 1;
        }
        else if (this.level == 4) {
            this.marineBase.marineSpawnInterval = 50;
            this.marineBase.marinesToSpawn = 8;
            this.alienBase.alienSpawnInterval = 10;
            this.alienBase.aliensToSpawn = 8;
        }
        else if (this.level < 10) {
            this.marineBase.marineSpawnInterval = 40;
            this.marineBase.marinesToSpawn = this.level;
            this.alienBase.alienSpawnInterval = 40;
            this.alienBase.aliensToSpawn = this.level * 1.3;
        }
        else {
            this.marineBase.marineSpawnInterval = 50;
            this.marineBase.marinesToSpawn = this.level;
            this.alienBase.alienSpawnInterval = 30;
            this.alienBase.aliensToSpawn = this.level * 2;
        }
    };
    GameScene.prototype.clearLevelText = function () {
        this.levelText.destroy();
    };
    return GameScene;
}(Phaser.Scene));
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = GameScene;
//# sourceMappingURL=gameScene.js.map
});

require.register("scenes/loadScene.ts", function(exports, require, module) {
/// <reference path="../defs/phaser.d.ts"/>
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var animations_1 = require("../animations/animations");
var LoadScene = (function (_super) {
    __extends(LoadScene, _super);
    function LoadScene(test) {
        return _super.call(this, {
            key: 'LoadScene'
        }) || this;
    }
    LoadScene.prototype.init = function (data) {
        console.log('init', data, this);
    };
    LoadScene.prototype.preload = function () {
        // dropship
        this.load.spritesheet('dropship', 'dropship.png', { frameWidth: 48, frameHeight: 16 });
        // units
        this.load.spritesheet('marine', 'marine.png', { frameWidth: 16, frameHeight: 16 });
        this.load.spritesheet('alien', 'alien.png', { frameWidth: 24, frameHeight: 24 });
        // effects
        this.load.spritesheet('effect', 'effect.png', { frameWidth: 32, frameHeight: 32 });
        this.load.spritesheet('pull', 'pull.png', { frameWidth: 64, frameHeight: 128 });
        // buildings
        this.load.spritesheet('base', 'base.png', { frameWidth: 80, frameHeight: 80 });
        // tiles
        this.load.spritesheet('ground', 'ground.png', { frameWidth: 16, frameHeight: 16 });
        // titles
        this.load.spritesheet('title', 'title.png', { frameWidth: 160, frameHeight: 64 });
        this.load.spritesheet('subtitle', 'subtitle.png', { frameWidth: 156, frameHeight: 18 });
        // titles
        this.load.spritesheet('text', 'text.png', { frameWidth: 128, frameHeight: 16 });
        this.load.image('background', 'background.png');
        this.load.image('directions', 'directions.png');
        // audio
        this.load.audio('pull', ['pull.wav']);
        this.load.audio('pickup', ['pickup.wav']);
        this.load.audio('dropoff', ['dropoff.wav']);
        this.load.audio('sword', ['sword.wav']);
        this.load.audio('rifle', ['rifle.wav']);
        this.load.audio('marinedeath', ['marinedeath.wav']);
        this.load.audio('orcdeath', ['orcdeath.wav']);
        /*
var music = this.sound.add('theme');

    music.play()
        */
        this.progressBar = this.add.graphics({ x: 0, y: 0 });
        this.load.on('progress', this.onLoadProgress, this);
        this.load.on('complete', this.onLoadComplete, this);
    };
    LoadScene.prototype.create = function () {
        animations_1.default(this);
    };
    LoadScene.prototype.update = function (time, delta) {
    };
    LoadScene.prototype.onLoadComplete = function () {
        this.scene.start('TitleScene');
    };
    LoadScene.prototype.onLoadProgress = function (progress) {
        this.progressBar
            .clear()
            .fillStyle(0xffffff, 0.75)
            .fillRect(0, 0, 800 * progress, 50);
        console.log('progress', progress);
    };
    return LoadScene;
}(Phaser.Scene));
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = LoadScene;
//# sourceMappingURL=loadScene.js.map
});

require.register("scenes/titleScene.ts", function(exports, require, module) {
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var TitleScene = (function (_super) {
    __extends(TitleScene, _super);
    function TitleScene(test) {
        return _super.call(this, {
            key: 'TitleScene'
        }) || this;
    }
    TitleScene.prototype.init = function (data) {
        console.log('init', data, this);
    };
    TitleScene.prototype.preload = function () {
        this.startKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.Z);
    };
    TitleScene.prototype.create = function () {
        var background = this.add.image(0, 0, 'background');
        background.setOrigin(0, 0);
        var directions = this.add.image(this.sys.game.config.width / 2, 180, 'directions');
        var title = this.add.sprite(this.sys.game.config.width / 2, 40, 'title');
        title.play('titleFlash');
        var subtitle = this.add.sprite(this.sys.game.config.width / 2, 70, 'subtitle');
        subtitle.play('subtitleIdle');
        this.cameras.main.fadeIn(2000);
    };
    TitleScene.prototype.update = function (time, delta) {
        if (this.startKey.isDown) {
            //var sound = this.sound.add('sword');
            //sound.play();
            this.input.stopPropagation();
            this.scene.start('GameScene');
        }
    };
    return TitleScene;
}(Phaser.Scene));
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = TitleScene;
//# sourceMappingURL=titleScene.js.map
});

require.register("tiles/tile.ts", function(exports, require, module) {
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Tile = (function (_super) {
    __extends(Tile, _super);
    function Tile(scene, x, y) {
        var _this = _super.call(this, scene, x, y, 'ground') || this;
        _this.scene.add.existing(_this);
        _this.scene.physics.add.existing(_this, true);
        return _this;
    }
    Tile.prototype.setFloor = function (floor) {
        if (floor)
            this.baseTile = 'floor';
        else
            this.baseTile = 'fill';
        this.tileVariation = Math.floor(Math.random() * 3);
        this.anims.play(this.baseTile + String(this.tileVariation));
    };
    Tile.prototype.update = function () {
    };
    return Tile;
}(Phaser.GameObjects.Sprite));
exports.Tile = Tile;
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Tile;
//# sourceMappingURL=tile.js.map
});

require.register("tiles/tilemap.ts", function(exports, require, module) {
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var tile_1 = require("../tiles/tile");
var marineBase_1 = require("../objects/marineBase");
var alienBase_1 = require("../objects/alienBase");
var Tilemap = (function (_super) {
    __extends(Tilemap, _super);
    function Tilemap(scene, worldSize) {
        var _this = _super.call(this, scene, 'tilemap') || this;
        _this.scene.add.existing(_this);
        _this.gameScene = scene;
        _this.mapCollision = _this.scene.physics.add.staticGroup();
        _this.size = new Phaser.Math.Vector2(Math.ceil(worldSize.x / 16), Math.ceil(worldSize.y / 16));
        _this.map = [];
        var currentGroundHeight = _this.size.y / 2;
        for (var i = 0; i < _this.size.x; i++) {
            _this.map[i] = [];
            for (var j = 0; j < _this.size.y; j++) {
                if (j > currentGroundHeight) {
                    _this.map[i][j] = new tile_1.default(scene, i * 16, j * 16);
                    if (!_this.map[i][j - 1]) {
                        _this.map[i][j].setFloor(true);
                        if (i == 10) {
                            _this.gameScene.marineBase = _this.gameScene.addUnit(new marineBase_1.default(_this.gameScene, i * 16 - 40, j * 16 - 45));
                        }
                        else if (i == _this.size.x - 10) {
                            _this.gameScene.alienBase = _this.gameScene.addUnit(new alienBase_1.default(_this.gameScene, i * 16 - 40, j * 16 - 45));
                        }
                    }
                    _this.mapCollision.add(_this.map[i][j]);
                }
            }
            var variation = Math.random();
            if (i > 20 && i < _this.size.x - 20) {
                if (variation > 0.8 && currentGroundHeight > 8) {
                    currentGroundHeight--;
                }
                else if (variation < 0.2 && currentGroundHeight < _this.size.y - 8) {
                    currentGroundHeight++;
                }
            }
        }
        return _this;
    }
    Tilemap.prototype.init = function (data) {
    };
    Tilemap.prototype.preload = function () {
    };
    Tilemap.prototype.create = function () {
    };
    Tilemap.prototype.update = function () {
    };
    return Tilemap;
}(Phaser.GameObjects.GameObject));
exports.Tilemap = Tilemap;
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Tilemap;
//# sourceMappingURL=tilemap.js.map
});

require.register("___globals___", function(exports, require, module) {
  
});})();require('___globals___');

require('initialize');
//# sourceMappingURL=app.js.map